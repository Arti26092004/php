<?php

    echo strtoupper("hello world!");

?>