<?php

    echo strtolower("Hello WORLD.");

?>