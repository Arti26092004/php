<?php
    // Deleting a cookie
    setcookie("username", "", time() - 3600);

    
?>
