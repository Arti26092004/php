<?php

    echo strpos("Hello world!","w");
   
?>