<?php

    echo substr("Hello world",6);

?>