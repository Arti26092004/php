<?php

    var_dump(checkdate(12,31,-400));
    var_dump(checkdate(2,29,2003));
    var_dump(checkdate(2,29,2004));

?>