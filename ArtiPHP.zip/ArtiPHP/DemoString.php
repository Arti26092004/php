<?php
// String declaration
$str = "Hello, World!";
$x=200;
$y=44.6;
echo"String is: $str";
?>