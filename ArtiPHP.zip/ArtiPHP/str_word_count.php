<?php

echo str_word_count("hello world!");
?>