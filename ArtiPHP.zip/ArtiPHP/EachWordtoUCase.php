<?php

    echo ucwords("hello world");

?>