<?php

    echo ucfirst("hello world!");

?>