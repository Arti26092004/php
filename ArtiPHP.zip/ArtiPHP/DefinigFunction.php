<?php

    // Defining function
    function test(){
        $greet = "Hello World!";
        echo $greet;
    }
     
    test(); // Outputs: Hello World!
     
    echo $greet; // Generate undefined variable error
    
?>