<?php

    echo strrev("Hello world!");

?> 