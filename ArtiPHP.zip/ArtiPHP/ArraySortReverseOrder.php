<?php

    // Define array
    $colors = array("Red", "Green", "Blue", "Yellow");
     
    // Sorting and printing array
    rsort($colors);
    print_r($colors);

?>