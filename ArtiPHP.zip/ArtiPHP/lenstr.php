<?php

    $my_str = "Welcome to Tutorial Republic";
     
    // Calculating and displaying string length
    echo strlen($my_str);

?>